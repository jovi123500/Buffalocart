package com.buffalocart.utilities;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


import com.google.common.collect.Table.Cell;



public class ExcelUtility 
{
	public XSSFSheet s;
	public ExcelUtility() throws IOException
	{
		FileInputStream f=new FileInputStream("C:\\Users\\jovita maven\\eclipse-workspace\\BuffaloCart\\src\\main\\resources\\sel_excel.xlsx");	
		XSSFWorkbook w=new XSSFWorkbook(f);
		s=w.getSheet("Sheet1");
			
	}	
	public String readData(int i,int j)
	{
		Row r=s.getRow(i);
		Cell c=r.getCell(j);
		int cellType=c.getCellType();
		switch(cellType) 
		{
			case Cell.CELL_TYPE_NUMERIC:
			{
				double data1=c.getNumericCellValue();
				int data=(int)data1;
				return String.valueOf(data); //convert to string
			}
			case Cell.CELL_TYPE_STRING:
			{
			return c.getStringCellValue();
			}	
		}
		return null;
		
	}

}
