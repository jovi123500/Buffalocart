package testscripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.buffalocart.automationcore.Base;
import com.buffalocart.pages.HomePage;
import com.buffalocart.pages.LoginPage;
import com.buffalocart.pages.RolesPage;
import com.buffalocart.pages.UserManagementPage;
import com.buffalocart.pages.UsersPage;

public class RolesTest extends Base
{
	LoginPage login;
	HomePage home;
	UserManagementPage mgmtpage;
	UsersPage userpage;
	RolesPage rolespage;
	
	@Test(enabled=true)
	public void verifyRolesPageTitle()
	{
	
	login=new LoginPage(driver);
	login.enterUsername("admin");
	login.enterPassword("123456");
	home=login.clickOnLoginButton();
	home.handleEndTour();
	mgmtpage=home.clickOnUserManagement();
	rolespage=mgmtpage.ClickOnRolesPage();
	rolespage.clickRoles();

	String actualuserPageTitle=driver.getTitle();
	String expecteduserPageTitle="Roles - Demo Company";
	Assert.assertEquals(actualuserPageTitle, expecteduserPageTitle,"Title Mismatch");
	}
	
	@Test(enabled=true)
	public void AddRoles()
	{
	login=new LoginPage(driver);
	login.enterUsername("admin");
	login.enterPassword("123456");
	home=login.clickOnLoginButton();
	home.handleEndTour();
	mgmtpage=home.clickOnUserManagement();
	rolespage=mgmtpage.ClickOnRolesPage();
	rolespage.clickRoles();
	rolespage.clickToAddRoles();
	}
}
