package com.buffalocart.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.buffalocart.utilities.PageUtility;

public class RolesPage extends PageUtility
{
	WebDriver driver;
	public RolesPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="/html/body/div[2]/aside/section/ul/li[2]/ul/li[2]/a")
	//@FindBy(xpath="//ul[@class='treeview-menu menu-open']//a//span[@class='title']")
	WebElement clickRoles;
	@FindBy(xpath="//div[@class='box-tools']/a")
	WebElement addUserData;
	
	public void clickRoles()
	{

	clickOnElement(clickRoles);
	}
	
	public AddRolePage clickToAddRoles()
	{
	clickOnElement(addUserData);
	return new AddRolePage(driver);
	}
	
}
