package testscripts;

import com.buffalocart.automationcore.Base;

public class UserManagementTest extends Base
{

}
