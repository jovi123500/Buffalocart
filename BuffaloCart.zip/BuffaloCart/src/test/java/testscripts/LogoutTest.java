package testscripts;

import com.buffalocart.automationcore.Base;

public class LogoutTest extends Base
{
	
}
