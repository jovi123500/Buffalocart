package testscripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.buffalocart.automationcore.Base;
import com.buffalocart.pages.AddRolePage;
import com.buffalocart.pages.HomePage;
import com.buffalocart.pages.LoginPage;
import com.buffalocart.pages.RolesPage;
import com.buffalocart.pages.UserManagementPage;

public class AddRoleTest extends Base
{
	LoginPage login;
	HomePage home;
	UserManagementPage mgmtpage;
	RolesPage rolespage;
	AddRolePage role;
	
	@Test(enabled=true)
	public void verifyUserPageTitle()
	{
	
	login=new LoginPage(driver);
	login.enterUsername("admin");
	login.enterPassword("123456");
	home=login.clickOnLoginButton();
	home.handleEndTour();
	mgmtpage=home.clickOnUserManagement();
	rolespage=mgmtpage.ClickOnRolesPage();
	rolespage.clickRoles();
	role=rolespage.clickToAddRoles();

	String actualuserPageTitle=driver.getTitle();
	String expecteduserPageTitle="Add Role-Demo Company";
	Assert.assertEquals(actualuserPageTitle, expecteduserPageTitle,"Title Mismatch");
	}
	
	@Test
	public void addRoles()
	{
		login=new LoginPage(driver);
		login.enterUsername("admin");
		login.enterPassword("123456");
		home=login.clickOnLoginButton();
		home.handleEndTour();
		mgmtpage=home.clickOnUserManagement();
		rolespage=mgmtpage.ClickOnRolesPage();
		rolespage.clickRoles();
		role=rolespage.clickToAddRoles();
		
		
		role.enterRolename("moncy");
		role.clickOnPermissionUser("View user");
		role.clickOnPermissionUser("Add user");
		role.clickOnPermissionRoles("View Role");
		role.clickOnPermissionSupplier("View supplier");
		role.clickOnPermissionCustomer("View customer");
		role.clickOnPermissionProduct("View product");
		role.clickOnPermissionPurchaseStock("  Add purchase & Stock Adjustment ");
		role.clickOnPermissionSell(" Add POS sell ");
		role.clickOnPermissionBrand("Add brand");
		role.clickOnPermissionTaxRate("View tax rate ");
		role.clickOnPermissionUnit("View unit");
		role.clickOnPermissionCategory(" View category ");
		role.clickOnPermissionReport("View Tax report");
		role.clickOnPermissionSetting("Access business settings");
		role.clickOnPermissionAccount(" All Locations ");
		role.clickOnSave();
	}
	
}
